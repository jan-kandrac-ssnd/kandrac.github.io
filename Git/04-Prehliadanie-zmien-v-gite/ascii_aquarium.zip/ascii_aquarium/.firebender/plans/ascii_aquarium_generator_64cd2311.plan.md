<!--firebender-plan
name: ASCII Aquarium Generator
overview: Build a C++ program that renders a static, randomly generated 30x15 ASCII aquarium populated with fish loaded dynamically from individual files in a `fish/` directory, delivered as at least 5 incremental commits on `main`.
-->


# ASCII Aquarium Plan

## Coding style constraint
- **Plain, procedural C++ only**: no classes, no member functions, no access modifiers (`class`/`struct` with methods forbidden). Use free functions, plain `struct`s with public data members only (C-style aggregates), global/`const` constants, arrays/`std::vector`, and C++ library calls (`std::cout`, `std::ifstream`, `std::filesystem`, `std::vector`, `<random>`, etc.). Think "C with iostream/filesystem/vector/string", not OOP C++.
- Everything lives in `[main.cpp](main.cpp)` as a flat sequence of `struct` data definitions + free functions + `main()`.

## Design summary
- **Aquarium size**: fixed interior 30 (width) x 15 (height) cells, defined as `const int` constants. Rendered inside a simple border (e.g. `+`, `-`, `|`), background is blank water (fish only, no plants/bubbles).
- **Fish source**: each file in `./fish/` (e.g. `fish/goldfish.txt`, `fish/shark.txt`) contains a small multi-line ASCII art fish. Adding a new `.txt` file to that directory makes it available to be randomly chosen next run — no code changes needed.
- **Loading**: a free function `loadFishTemplates(path)` uses `std::filesystem` to iterate all regular files in `fish/`, reads each into a `FishTemplate` plain struct (`{ int width; int height; std::vector<std::string> lines; }`), padding lines to equal width. Returns `std::vector<FishTemplate>`.
- **Random placement**: for a random target coverage between 10% and 20% of the 30x15 = 450 cells:
  - A free function repeatedly picks a random fish template, randomly flips it horizontally via a `flipFishHorizontally(FishTemplate)` free function (mirroring direction characters like `>`/`<`, `(`/`)`), then tries random (x, y) positions.
  - A 2D occupancy array/vector (plain data, no class) tracks used cells to reject overlapping placements (retry with a cap on attempts).
  - Accepted fish are stamped into the character grid via a free function; its bounding-box area is added to a running coverage total; stop once coverage reaches the target (or after a max total attempts safeguard).
- **Rendering**: a free function prints the bordered grid once to stdout; program exits (static snapshot, not animated).
- **Build support**: update `[CMakeLists.txt](CMakeLists.txt)` with a post-build step to copy `fish/` next to the built executable, so running from CLion's default working directory still finds the fish files.
- Add a short `[README.md](README.md)` explaining how to add new fish files.

## Commit plan (6 commits on `main`)

1. **Aquarium skeleton**: add `WIDTH=30`/`HEIGHT=15` constants and a free function to render an empty bordered tank; `main()` prints the empty aquarium. Verifies grid/border logic works before adding fish.
2. **Fish loading**: introduce plain `FishTemplate` struct and free function `loadFishTemplates("fish")` using `std::filesystem` to read all files in the directory; add 2 sample fish files (e.g. `fish/goldfish.txt`, `fish/betta.txt`); update `CMakeLists.txt` to copy `fish/` to the build output directory post-build.
3. **Random placement engine**: add occupancy grid (plain 2D vector), coverage calculation (10-20% of 450 cells), and free functions to randomly place non-overlapping fish templates onto the character grid using `<random>`.
4. **Horizontal flip/orientation**: add a free `flipFishHorizontally` function (reverse each line, swap direction glyphs like `<`/`>`, `(`/`)`) applied randomly per placed fish for visual variety.
5. **Wire-up + more fish variety**: integrate loading + placement + flip + rendering calls into `main()` to produce the final random aquarium output; add 3 more sample fish files (total ~5) with varied shapes/sizes.
6. **Docs polish**: add `README.md` describing the aquarium, how coverage/placement works, and how to drop a new `.txt` file into `fish/` to add a fish.

## Key files
- `[main.cpp](main.cpp)` — all program logic as free functions + plain structs (grid, fish loading, placement, rendering, `main`).
- `[CMakeLists.txt](CMakeLists.txt)` — add post-build copy of `fish/`.
- `fish/*.txt` — sample fish ASCII art files (new directory).
- `[README.md](README.md)` — new, brief usage docs.
</plan>
<todos>[{"id":"commit1","content":"Commit 1: empty bordered 30x15 aquarium skeleton"},{"id":"commit2","content":"Commit 2: fish file loading + sample fish + CMake copy step"},{"id":"commit3","content":"Commit 3: random non-overlapping placement with 10-20% coverage target"},{"id":"commit4","content":"Commit 4: horizontal flip/mirroring for fish orientation variety"},{"id":"commit5","content":"Commit 5: wire everything into main() + add more sample fish files"},{"id":"commit6","content":"Commit 6: add README documenting fish directory usage"}]
