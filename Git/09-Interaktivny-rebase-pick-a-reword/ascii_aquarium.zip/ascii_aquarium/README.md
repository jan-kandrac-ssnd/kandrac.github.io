# ASCII Aquarium

A tiny C++ program that prints a randomly generated ASCII aquarium to the
terminal. Every run picks a random selection of fish, places them at random
(non-overlapping) positions, and prints the result once.

```
+------------------------------+
|        <><((('>              |
|                               |
|      /\                      |
|     <o )===        __        |
|      \/           >=(o>      |
|                     --        |
+------------------------------+
```

## How it works

- The aquarium is a fixed **30 x 15** grid of cells.
- Fish are randomly picked and placed until they cover roughly **10-20%** of
  the aquarium's cells, without overlapping each other.
- Each placed fish has a 50% chance of being mirrored horizontally, so it can
  appear to swim left or right.
- The program is a single, static snapshot: it prints one aquarium and exits.

## Adding a new fish

Fish are not hard-coded. Each file in the [`fish/`](fish) directory is a
plain text sprite that is loaded automatically at startup, so **just add a
new `.txt` file to `fish/` and it becomes available the next time you run
the program** - no code changes required.

Rules for a fish file:

- Each line of the file becomes one row of the fish's ASCII art.
- Rows may have different lengths; shorter rows are padded with spaces to
  match the widest row in the file.
- The whole sprite must fit within the 30 x 15 aquarium (in practice, keep
  fish small so several can fit at once).
- Optional: use `<`, `>`, `(`, `)`, `/`, `\` for the "business end" of the
  fish (nose/tail) - these characters are automatically swapped when a fish
  is mirrored, so it keeps facing the right way when flipped.

For example, `fish/minnow.txt` contains a single line:

```
<><((('>
```

## Building and running

```bash
cmake -S . -B build
cmake --build build
./build/ascii_aquarium
```

Run it a few times to see different random layouts.
