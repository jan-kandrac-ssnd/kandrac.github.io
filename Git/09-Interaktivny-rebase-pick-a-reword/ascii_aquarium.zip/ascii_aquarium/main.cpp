#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <filesystem>
#include <random>

using namespace std;
namespace fs = std::filesystem;

// Interior dimensions of the aquarium tank.
const int AQUARIUM_WIDTH = 80;
const int AQUARIUM_HEIGHT = 15;

// Directory (relative to the working directory) that holds one ASCII fish
// per file. Drop a new .txt file in there and it becomes available too.
const string FISH_DIRECTORY = "fish";

// Fish should cover somewhere between 10% and 20% of the aquarium's cells.
const double MIN_COVERAGE_FRACTION = 0.10;
const double MAX_COVERAGE_FRACTION = 0.20;

// Safety net so placement always terminates even if fish don't fit well.
const int MAX_PLACEMENT_ATTEMPTS = 1000;

// A 2D grid of characters representing the water and everything in it.
typedef vector<string> Grid;

// A 2D grid of booleans marking which cells are already used by a fish.
typedef vector<vector<bool> > OccupancyGrid;

// A single fish "sprite" loaded from a file: its lines of ASCII art plus
// the bounding box (width/height) of those lines.
struct FishTemplate {
    int width = 0;
    int height = 0;
    vector<string> lines;
};

// Reads every regular file in `directory` and turns it into a FishTemplate.
// Each line of a file becomes one row of the fish; shorter rows are padded
// with spaces so every row has the same width.
vector<FishTemplate> loadFishTemplates(const string &directory) {
    vector<FishTemplate> templates;

    if (!fs::exists(directory) || !fs::is_directory(directory)) {
        return templates;
    }

    for (const auto &entry : fs::directory_iterator(directory)) {
        if (!entry.is_regular_file()) {
            continue;
        }

        ifstream file(entry.path());
        if (!file) {
            continue;
        }

        vector<string> lines;
        string line;
        int maxWidth = 0;
        while (getline(file, line)) {
            // Strip a trailing carriage return in case the file has
            // Windows-style line endings.
            if (!line.empty() && line.back() == '\r') {
                line.pop_back();
            }
            lines.push_back(line);
            maxWidth = max(maxWidth, static_cast<int>(line.size()));
        }

        if (lines.empty() || maxWidth == 0) {
            continue;
        }

        for (string &row : lines) {
            row.resize(maxWidth, ' ');
        }

        FishTemplate fish;
        fish.width = maxWidth;
        fish.height = static_cast<int>(lines.size());
        fish.lines = lines;
        templates.push_back(fish);
    }

    return templates;
}

// Creates an empty aquarium grid filled with water (blank space).
Grid createEmptyGrid() {
    Grid grid(AQUARIUM_HEIGHT, string(AQUARIUM_WIDTH, ' '));
    return grid;
}

// Creates an occupancy grid, initially with every cell free (false).
OccupancyGrid createEmptyOccupancyGrid() {
    OccupancyGrid occupancy(AQUARIUM_HEIGHT, vector<bool>(AQUARIUM_WIDTH, false));
    return occupancy;
}

// True if the fish's bounding box fits inside the aquarium at (x, y) and
// does not overlap any cell already occupied by another fish.
bool regionIsFree(const OccupancyGrid &occupancy, int x, int y, int width, int height) {
    if (x < 0 || y < 0 || x + width > AQUARIUM_WIDTH || y + height > AQUARIUM_HEIGHT) {
        return false;
    }

    for (int row = 0; row < height; row++) {
        for (int col = 0; col < width; col++) {
            if (occupancy[y + row][x + col]) {
                return false;
            }
        }
    }

    return true;
}

// Mirrors a single character so that direction-ish glyphs still look right
// once a fish is flipped, e.g. a nose '>' becomes '<' when facing left.
char mirrorChar(char c) {
    switch (c) {
        case '<': return '>';
        case '>': return '<';
        case '(': return ')';
        case ')': return '(';
        case '/': return '\\';
        case '\\': return '/';
        default: return c;
    }
}

// Returns a copy of `fish` mirrored horizontally (reversed rows, with
// direction glyphs swapped) so it appears to swim the other way.
FishTemplate flipFishHorizontally(const FishTemplate &fish) {
    FishTemplate flipped;
    flipped.width = fish.width;
    flipped.height = fish.height;
    flipped.lines.resize(fish.height);

    for (int row = 0; row < fish.height; row++) {
        string flippedRow(fish.width, ' ');
        for (int col = 0; col < fish.width; col++) {
            char c = fish.lines[row][fish.width - 1 - col];
            flippedRow[col] = mirrorChar(c);
        }
        flipped.lines[row] = flippedRow;
    }

    return flipped;
}

// Copies the fish's ASCII art into the grid at (x, y) and marks its whole
// bounding box as occupied so no other fish can be placed on top of it.
void stampFish(Grid &grid, OccupancyGrid &occupancy, const FishTemplate &fish, int x, int y) {
    for (int row = 0; row < fish.height; row++) {
        for (int col = 0; col < fish.width; col++) {
            char c = fish.lines[row][col];
            if (c != ' ') {
                grid[y + row][x + col] = c;
            }
            occupancy[y + row][x + col] = true;
        }
    }
}

// Randomly places fish templates into the aquarium until fish cover roughly
// MIN_COVERAGE_FRACTION to MAX_COVERAGE_FRACTION of its cells, avoiding any
// overlap between fish.
void populateAquariumWithFish(Grid &grid, const vector<FishTemplate> &fishTemplates, mt19937 &rng) {
    if (fishTemplates.empty()) {
        return;
    }

    OccupancyGrid occupancy = createEmptyOccupancyGrid();
    const int totalCells = AQUARIUM_WIDTH * AQUARIUM_HEIGHT;

    uniform_real_distribution<double> coverageDist(MIN_COVERAGE_FRACTION, MAX_COVERAGE_FRACTION);
    double targetCoverage = coverageDist(rng);

    uniform_int_distribution<size_t> fishDist(0, fishTemplates.size() - 1);
    bernoulli_distribution flipDist(0.5);

    int coveredCells = 0;
    int attempts = 0;

    while (attempts < MAX_PLACEMENT_ATTEMPTS &&
           static_cast<double>(coveredCells) / totalCells < targetCoverage) {
        attempts++;

        const FishTemplate &original = fishTemplates[fishDist(rng)];
        FishTemplate fish = flipDist(rng) ? flipFishHorizontally(original) : original;
        if (fish.width > AQUARIUM_WIDTH || fish.height > AQUARIUM_HEIGHT) {
            continue;
        }

        int fishArea = fish.width * fish.height;
        double projectedCoverage = static_cast<double>(coveredCells + fishArea) / totalCells;
        if (projectedCoverage > MAX_COVERAGE_FRACTION) {
            continue;
        }

        uniform_int_distribution<int> xDist(0, AQUARIUM_WIDTH - fish.width);
        uniform_int_distribution<int> yDist(0, AQUARIUM_HEIGHT - fish.height);
        int x = xDist(rng);
        int y = yDist(rng);

        if (!regionIsFree(occupancy, x, y, fish.width, fish.height)) {
            continue;
        }

        stampFish(grid, occupancy, fish, x, y);
        coveredCells += fishArea;
    }
}

// Prints the aquarium grid surrounded by a simple border.
void printAquarium(const Grid &grid) {
    string horizontalBorder = "+" + string(AQUARIUM_WIDTH, '-') + "+";

    cout << horizontalBorder << "\n";
    for (int row = 0; row < AQUARIUM_HEIGHT; row++) {
        cout << "|" << grid[row] << "|\n";
    }
    cout << horizontalBorder << "\n";
}

int main() {
    vector<FishTemplate> fishTemplates = loadFishTemplates(FISH_DIRECTORY);

    random_device seedSource;
    mt19937 rng(seedSource());

    Grid grid = createEmptyGrid();
    populateAquariumWithFish(grid, fishTemplates, rng);
    printAquarium(grid);
    return 0;
}
